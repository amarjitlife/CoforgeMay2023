
package main

//	Package
import "fmt"

func main() {
	fmt.Println("Hello World!!!!")
}
