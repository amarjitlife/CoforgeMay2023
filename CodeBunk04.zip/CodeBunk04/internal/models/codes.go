package models

import (
	"database/sql"
	"time"
)
// _________________________________________________________________

// Creating Code Model
type Code struct {
	ID int
	Title string
	Content string
	Created time.Time
	Expires time.Time
}

type CodeModel struct {
	DB * sql.DB
}

// _________________________________________________________________

// Inserting New Code Record In The DB
// Attempt 01 : Skeleton Code
// func ( m * CodeModel ) Insert( title string, content string, expires int )( int, error ) {
// 	return 0, nil 
// }

// Attempt 02 : Skeleton Code
func (m *CodeModel) Insert(title string, content string, expires int)(int,error ) {
	stmt := `INSERT INTO codes (title, content, created, expires) VALUES(?, ?, UTC_TIMESTAMP(), DATE_ADD( UTC_TIMESTAMP(), INTERVAL ? DAY))`
	

	result, err := m.DB.Exec(stmt, title, content, expires)
	if err != nil {
		return 0, err
	}

	id, err := result.LastInsertId()
	if err != nil {
		return 0, nil 
	}

	return int(id), nil 
}

// Getting Code With ID Record From The DB
func ( m * CodeModel ) Get( id int ) ( *Code , error ) {
	return nil, nil 
}

// Getting 10 Most Receentlry Code Records From The DB
func ( m * CodeModel ) Lastest() ( []*Code, error ) {
	return nil, nil 
}

// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________


