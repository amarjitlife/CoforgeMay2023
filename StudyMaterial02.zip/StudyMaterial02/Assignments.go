_______________________________________________________________

DAY 01
_______________________________________________________________


Assignment A1: Reading and Coding/Experiment Assignment
	Reference Book : The C Programming Language, 2nd Edition
					 	By Dennis Ritchie and Ken Thomson

		Chapter 02: Types, Operations and Expressions


Assignment A2: Go Coding and Revision Assignment
	Practice and Experimentt Go Code Done Till Now


Assignment A3: Thinking and Exploration Assignment
	1. Command Line Arguments Nature In C/C++/Java/C#/Go Language
	2. What Are Design Choices In A Language Possible For Command Line Arguments
	3. Which Design Choice Is Better Design
	4. Who Calls The main Function In C/C++/Java/C#?
	5. Who Pass The Command Line Arguments to main Function In C/C++/Java/C#


_______________________________________________________________

DAY 02
_______________________________________________________________


Assignment A1: Reading and Coding/Experiment Assignment
	Reference Book : The C Programming Language, 2nd Edition
					 	By Dennis Ritchie and Ken Thomson

		Chapter 02: Types, Operations and Expressions
		Chapter 03: Control Flows 
	
Assignment A2: Thinking and Exploration Assignment
	Practice and Experimentt Go Code Done Till Now

_______________________________________________________________

DAY 03
_______________________________________________________________



_______________________________________________________________

DAY 04
_______________________________________________________________



_______________________________________________________________

DAY 05
_______________________________________________________________


