package main

import (
	"example.com/codebunk/internal/models"
)

type templateData struct {
	Code *models.Code
	Codes []*models.Code
	// More Memeber You Can Add...
}
