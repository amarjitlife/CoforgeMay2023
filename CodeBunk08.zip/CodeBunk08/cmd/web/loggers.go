package main

import(
	"log"
	"os"
)

// Logger Design 01
// ___________________________________________________________________
// IS IT GOOD DESIGN???
//		AVOID GLOBAL VARIABLES It's BAD DESIGN
// Creating INFO Logger
// var infoLog  = log.New( os.Stdout, "INFO\t", log.Ldate|log.Ltime )
// // Creating ERROR Logger
// var errorLog = log.New( os.Stderr, "ERROR\t", log.Ldate|log.Ltime|log.Lshortfile )

// Logger Design 02
// ___________________________________________________________________

type Loggers struct {
	infoLog 	* log.Logger
	errorLog 	* log.Logger
}

var logger = Loggers {
	infoLog		: log.New( os.Stdout, "INFO\t", log.Ldate|log.Ltime ),
	errorLog 	: log.New( os.Stderr, "ERROR\t", log.Ldate|log.Ltime|log.Lshortfile ),
}

// Singleton Pattern : Returning Singleton Instance Of Looger
func GetLogger() Loggers {
	// var logger = Loggers {
	// 	infoLog		: log.New( os.Stdout, "INFO\t", log.Ldate|log.Ltime ),
	// 	errorLog 	: log.New( os.Stderr, "ERROR\t", log.Ldate|log.Ltime|log.Lshortfile ),
	// }
	return logger
}

// ___________________________________________________________________

