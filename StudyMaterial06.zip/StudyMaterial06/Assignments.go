_______________________________________________________________

DAY 01
_______________________________________________________________


Assignment A1: Reading and Coding/Experiment Assignment
	Reference Book : The C Programming Language, 2nd Edition
					 	By Dennis Ritchie and Ken Thomson

		Chapter 02: Types, Operations and Expressions


Assignment A2: Go Coding and Revision Assignment
	Practice and Experimentt Go Code Done Till Now


Assignment A3: Thinking and Exploration Assignment
	1. Command Line Arguments Nature In C/C++/Java/C#/Go Language
	2. What Are Design Choices In A Language Possible For Command Line Arguments
	3. Which Design Choice Is Better Design
	4. Who Calls The main Function In C/C++/Java/C#?
	5. Who Pass The Command Line Arguments to main Function In C/C++/Java/C#

_______________________________________________________________

DAY 02
_______________________________________________________________


Assignment A1: Reading and Coding/Experiment Assignment
	Reference Book : The C Programming Language, 2nd Edition
					 	By Dennis Ritchie and Ken Thomson
		Chapter 02: Types, Operations and Expressions
		Chapter 03: Control Flows 
	
Assignment A2: Go Coding and Revision Assignment
	Practice and Experimentt Go Code Done Till Now

Assignment A3: Thinking and Exploration Assignment
	Single Precision Floating Points
	Double Precision Floating Points

_______________________________________________________________

DAY 03
_______________________________________________________________

Assignment A1: Reading and Coding/Experiment Assignment
	Reference Book : The C Programming Language, 2nd Edition
					 	By Dennis Ritchie and Ken Thomson
		Chapter 02: Types, Operations and Expressions
		Chapter 03: Control Flows
		Chapter 04: Functions
	
Assignment A2: Go Coding and Revision Assignment
	Practice and Experimentt Go Code Done Till Now

Assignment A3: Deeper Thinking and Understanding Assignment
	Single Precision Floating Points
	Double Precision Floating Points

	Introduction To Unicode
	https://www.joelonsoftware.com/2003/10/08/the-absolute-minimum-every-software-developer-absolutely-positively-must-know-about-unicode-and-character-sets-no-excuses/
	https://digitaltools.labcd.unipi.it/wp-content/uploads/2021/05/Introduction-to-Unicode.pdf

_______________________________________________________________

DAY 04
_______________________________________________________________

Assignment A1: Reading and Coding/Experiment Assignment
	Reference Book : The C Programming Language, 2nd Edition
					 	By Dennis Ritchie and Ken Thomson
		Chapter 02: Types, Operations and Expressions
		Chapter 03: Control Flows
		Chapter 04: Functions
		Chapter 05: Pointers And Arrays [ MUST MUST MUST ]

Assignment A2: Go Coding and Revision Assignment
	Practice and Experimentt Go Code Done Till Now

Assignment A3: Deeper Thinking and Understanding Assignment
	Explore String Type Design In Java Language?
	How String In Java Works Internally?
	Is C char Signed or Unsigned By Default?
	What Is The Design Principle Behind char Default Range?

_______________________________________________________________

DAY 05
_______________________________________________________________

Assignment A1: Reading and Coding/Experiment Assignment
	Reference Book : The C Programming Language, 2nd Edition
					 	By Dennis Ritchie and Ken Thomson
		Chapter 05: Pointers And Arrays [ MUST MUST MUST ]
		Practice C Code Examples In Array And Pointers Topics

Assignment A2: Go Coding and Revision Assignment
	Practice and Experimentt Go Code Done Till Now

Assignment A3: Deeper Thinking and Understanding Assignment
	Read Documentation of Println and Printf Functions in Go fmt Package
		Reference For Format Specifiers
			https://pkg.go.dev/fmt
	Read and Understand Bitwise Operators

_______________________________________________________________

DAY 06
_______________________________________________________________

Assignment A1: Reading and Coding/Experiment Assignment
	Reference Book : The C Programming Language, 2nd Edition
					 	By Dennis Ritchie and Ken Thomson
		Chapter 05: Pointers And Arrays [ MUST MUST MUST ]
		Practice C Code Examples In Array And Pointers Topics

Assignment A2: Go Coding and Revision Assignment
	Practice and Experimentt Go Code Done Till Now

Assignment A3: Deeper Thinking and Understanding Assignment
	Practice C Pointers and Arrays Relationships
	Read Concepts Related To Pass By Value/Reference

_______________________________________________________________

DAY 07
_______________________________________________________________



_______________________________________________________________

DAY 08
_______________________________________________________________

