package main

import (
	"fmt"
	"net/http"
	"runtime/debug"
)

// _________________________________________________________________
// _________________________________________________________________

func (app *application) render( w http.ResponseWriter, status int, page string, data *templateData) {

	template, ok := app.templateCache[ page ]
	if !ok {
		err := fmt.Errorf("The Template %s Doesn't Exists...", page)
		app.serverError( w, err )
		return
	}

	w.WriteHeader( status )

	err := template.ExecuteTemplate( w, "base", data )
	if err != nil {
		app.serverError( w, err )
	}
}

// _________________________________________________________________
// _________________________________________________________________


func (app *application) serverError( w http.ResponseWriter, err error ) {
	// In the serverError() helper we use the debug.Stack() function to 
	// get a stack trace for the current goroutine and append it to the 
	// log message. Being able to see the execution path of the application 
	// via the stack trace can be helpful when you’re trying to debug errors.

	trace := fmt.Sprintf("%s\n%s", err.Error(), debug.Stack() )
	// app.errorLog.Println( trace )
	app.errorLog.Output(2, trace )

	http.Error(w, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
}

func (app *application) clientError( w http.ResponseWriter, status int ) {
	// In the clientError() helper we use the http.StatusText() function 
	// to automatically generate a human-friendly text representation of 
	// a given HTTP status code. For example, http.StatusText(400) will 
	// return the string "Bad Request".

	http.Error(w, http.StatusText( status ), http.StatusInternalServerError)
}

// _________________________________________________________________

func (app *application) notFound( w http.ResponseWriter) {
	app.clientError(w, http.StatusNotFound)
}

// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
