
#include <stdio.h>

void playWithCommandLineArgs(int argc, char *argv[]) {
	for ( int i = 0 ; i < argc ; i++ ) {
		printf("\n Argument Value At %d = %s", i, argv[i] );
	}
}


int main(int argc, char *argv[]) {
	printf("\n\nFunction : playWithCommandLineArgs");
	playWithCommandLineArgs( argc, argv );


	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");	
}

