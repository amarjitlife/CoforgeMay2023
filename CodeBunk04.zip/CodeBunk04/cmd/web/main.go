package main

import (
	"net/http"
	"os"
	"flag"
	"log"

	"example.com/codebunk/internal/models"

	"database/sql"
	_ "github.com/go-sql-driver/mysql"
)

// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________

// Logger Design 03 : Application Wide Configuration Management Design
// Configuring Application Wide Configurations
type application struct {
	// Adding Logging Configuration
	infoLog 	* log.Logger
	errorLog 	* log.Logger
	codes 		* models.CodeModel
}

// _________________________________________________________________
// _________________________________________________________________

func main() {
	//1. Get Configuration
	// go run ./cmd/web/ -address=":8000"
	address := flag.String("address", ":4000", "HTTP Network Address")
	dsn := flag.String("dsn", "web:codebunk@/codebunkdb?parseTime=true", "MySQL Database Source Name")

	flag.Parse()

	infoLog 	:= log.New( os.Stdout, "INFO\t", log.Ldate|log.Ltime )
	errorLog 	:= log.New( os.Stderr, "ERROR\t", log.Ldate|log.Ltime|log.Lshortfile )

	//2.1 Configure Application : Database Connection
	db, dberr := openDB(*dsn)
	if dberr != nil {
		errorLog.Println("Databse Connection Error Happened: ", dberr)	
	}
	// Closing Connection Pool Before main() Function Exit
	defer db.Close()

	//2.2 Configure Application : Logging
	// Logger Design 03 Using Application 
	app := &application {
		infoLog  : infoLog,
		errorLog : errorLog,
		codes 	 : &models.CodeModel{ DB : db },
	}

	//2.3 Configure HTTP Server
	server := &http.Server {
		Addr: *address,
		ErrorLog: app.errorLog,
		Handler: app.routes(),
	}

	// Logger Design 03
	app.infoLog.Println("Starting Server On Port: ", *address)
	//3. Start HTTP Server
	err := server.ListenAndServe() // Registering Multiplexer
	if err != nil {
		app.errorLog.Println("Error Happened: ", err)
	}
	// Logger Design 03
	app.infoLog.Println("Starting Server On Port: ", *address)
}

// _________________________________________________________________

// The openDB Function Retuns sql.DB Connection Pool
func openDB( dsn string ) (*sql.DB, error) {
	db, dberr := sql.Open("mysql", dsn)

	if dberr != nil {
		return nil, dberr
	}

	if dberr = db.Ping() ; dberr != nil {
		return nil, dberr
	}

	return db, nil
}

// _________________________________________________________________

// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________

