
mkdir HTMLParse
cd HTMLParse/
clear
ls
ls -l
go mod init
go mod init example.com/htmlparse
ls
cat go.mod
cat main.go
go run .
go mod tidy
cat go.mod
go run .

