package models

import (
	"database/sql"
	"time"
	"errors"
)
// _________________________________________________________________

// Creating Code Model
//		To Hold The Data Of Indivisual Code
type Code struct {
	ID int
	Title string
	Content string
	Created time.Time
	Expires time.Time
}

type CodeModel struct {
	DB * sql.DB
}

// _________________________________________________________________

// Inserting New Code Record In The DB
// Attempt 01 : Skeleton Code
// func ( m * CodeModel ) Insert( title string, content string, expires int )( int, error ) {
// 	return 0, nil 
// }

// Attempt 02 : Skeleton Code
func (m *CodeModel) Insert(title string, content string, expires int)(int, error) {
	statement := `INSERT INTO codes (title, content, created, expires) 
	VALUES(?, ?, UTC_TIMESTAMP(), DATE_ADD( UTC_TIMESTAMP(), INTERVAL ? DAY))`
	
	// Using the ? character to indicate placeholder parameters for 
	// the data that we want to insert in the database

    // Use the Exec() method on the embedded connection pool to execute the
    // statement. The first parameter is the SQL statement, followed by the
    // title, content and expiry values for the placeholder parameters. This
    // method returns a sql.Result type, which contains some basic
    // information about what happened when the statement was executed.
	result, err := m.DB.Exec(statement, title, content, expires)
	if err != nil {
		return 0, err
	}

    // Use the LastInsertId() method on the result to get the ID of our
    // newly inserted record in the codes table.
	id, err := result.LastInsertId()
	if err != nil {
		return 0, nil 
	}

    // The ID returned has the type int64, so we convert it to an int type
    // before returning.
	return int(id), nil 
}

// Go provides three different methods for executing database queries:
// 	DB.Query() is used for SELECT queries which return multiple rows.
// 	DB.QueryRow() is used for SELECT queries which return a single row.
// 	DB.Exec() is used for statements which don’t return rows 
//		(like INSERT and DELETE ).

// ________________________________________________________________

// Placeholder Parameters
// ________________________________________________________________
// In the code above we constructed our SQL statement using placeholder 
// parameters, where ? acted as a placeholder for the data we want to insert.

// The reason for using placeholder parameters to construct our query 
// (rather than string interpolation) is to help avoid SQL injection attacks 
// from any untrusted user-provided input.

// ________________________________________________________________

// Behind the scenes, the DB.Exec() method works in three steps:
// ________________________________________________________________
// It creates a new prepared statement on the database using 
// the provided SQL statement. The database parses and compiles 
// the statement, then stores it ready for execution.

// In a second separate step, Exec() passes the parameter values to 
// the database. The database then executes the prepared statement 
// using these parameters. Because the parameters are transmitted later, 
// after the statement has been compiled, the database treats them as 
// pure data. They can’t change the intent of the statement. So long 
// as the original statement is not derived from an untrusted data, 
// injection cannot occur.

// It then closes (or deallocates) the prepared statement on the database.

// The placeholder parameter syntax differs depending on your database. 
// MySQL, SQL Server and SQLite use the ? notation, but 
// PostgreSQL uses the $N notation. 
// For example, if you were using PostgreSQL instead you would write:
// _, err := m.DB.Exec("INSERT INTO ... VALUES ($1, $2, $3)", ...)

// ________________________________________________________________

// Getting Code With ID Record From The DB
// Attempt 01
// func ( m * CodeModel ) Get( id int ) ( *Code , error ) {
// 	return nil, nil 
// }

// Attempt 02
func ( m * CodeModel ) Get( id int ) ( *Code , error ) {
	statement := `SELECT id, title, content, created, expires FROM codes
		WHERE expires > UTC_TIMESTAMP() AND id = ?`

	row := m.DB.QueryRow( statement, id )
	code := &Code{}

    // Use row.Scan() to copy the values from each field in sql.Row to the
    // corresponding field in the Code struct. Notice that the arguments
    // to row.Scan are *pointers* to the place you want to copy the data into,
    // and the number of arguments must be exactly the same as the number of
    // columns returned by your statement.
	err := row.Scan( &code.ID, &code.Title, &code.Content, &code.Created, &code.Expires)

	if err != nil {
		if errors.Is( err, sql.ErrNoRows ) {
			return nil, ErrNoRecord
		} else {
			return nil, err
		}
	}

	return code, nil 
}

// Behind the scenes of rows.Scan() your driver will automatically 
// convert the raw output from the SQL database to the required native 
// Go types. So long as you’re sensible with the types that you’re 
// mapping between SQL and Go, these conversions should generally 
// Just Work. Usually:

// CHAR, VARCHAR and TEXT map to string.
// BOOLEAN maps to bool.
// INT maps to int; BIGINT maps to int64.
// DECIMAL and NUMERIC map to float.
// TIME, DATE and TIMESTAMP map to time.Time.

// ________________________________________________________________

// Getting 10 Most Receentlry Code Records From The DB
func ( m * CodeModel ) Lastest() ( []*Code, error ) {
	return nil, nil 
}

// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________

